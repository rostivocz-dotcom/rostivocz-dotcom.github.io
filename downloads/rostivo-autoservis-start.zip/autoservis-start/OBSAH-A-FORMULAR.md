# Autoservis Start — obsah a poptávka

## Doporučené pořadí stránky

1. **Hlavní nabídka:** komu pomáháte, v jakém městě a jaký je první krok.
2. **Služby:** servis, pneu, diagnostika, příprava na STK; každá s krátkým konkrétním popisem.
3. **Důvody důvěry:** zkušenost, kvalifikace, typy vozů, transparentní postup, reálné recenze pouze se souhlasem.
4. **Jak to probíhá:** poptávka → potvrzení termínu → servis → předání.
5. **Kontakt:** telefon jako klikatelné číslo, otevírací doba, místo, e-mail a jednoduchá poptávka.

## Formulář: minimální kvalifikace

- jméno a preferovaný kontakt;
- typ vozidla a orientační problém;
- požadovaná služba;
- preferovaný termín;
- souhlas s kontaktováním a odkaz na ochranu soukromí.

Nechtějte při prvním kroku VIN, rodné číslo, platební údaje ani jiná data, která pro rozhodnutí o termínu nepotřebujete.

## Kontrola před zveřejněním

- [ ] Telefon spustí volání na mobilu.
- [ ] E-mail a adresa jsou aktuální.
- [ ] Formulář dorazí do správné schránky a obsahuje potvrzení.
- [ ] Fotografie nemají zavádějící popisky ani cizí licencovaný obsah bez oprávnění.
- [ ] Mobilní menu, služby a CTA jsou čitelné bez vodorovného posunu.

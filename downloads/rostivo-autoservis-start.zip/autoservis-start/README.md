# Autoservis Start — interní balíček

Balíček obsahuje samostatnou statickou startovní šablonu pro autoservis, pneuservis nebo detailing. Je určená jako rychlý pracovní základ; neobsahuje napojení na rezervační systém, odesílání formulářů ani hosting.

## Obsah

| Soubor | Účel |
|---|---|
| `site/index.html` | Samostatná responsivní výchozí šablona bez závislostí |
| `OBSAH-A-FORMULAR.md` | Textová kostra, otázky pro poptávkový formulář a kontrola před spuštěním |
| `../LICENCE-INTERNI-POUZITI.md` | Pravidla interního použití |

## Rychlý postup

1. Otevřete `site/index.html` v prohlížeči a zkontrolujte strukturu.
2. Vyměňte název firmy, telefon, e-mail, město, otevírací dobu a příklady služeb.
3. Doplňte vlastní fotografie, ke kterým máte právo použití; ponechte u nich smysluplný alternativní text.
4. Připojte formulář ke schválené e-mailové službě nebo CRM; před spuštěním proveďte test z mobilu.
5. Zkontrolujte HTTPS, doménu, zásady soukromí, viditelnost telefonu a cíl každé hlavní CTA.

> Šablona je výchozí návrh. Odpovědnost za ceny, konkrétní služby, právní texty a skutečné objednávkové procesy zůstává na provozovateli webu.

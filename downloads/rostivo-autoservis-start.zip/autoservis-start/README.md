# Autoservis Start — vizuální webová šablona

![Náhled Autoservis Start](assets/autoservis-hero.webp)

> **Hook:** Z návštěvy ke konkrétnímu termínu — ne k neurčitému telefonátu.

Toto není jen prázdný HTML soubor. Je to výchozí stránka pro autoservis, pneuservis nebo detailing, která už ukazuje **reálnou práci v dílně**, srozumitelně vysvětluje služby a vede návštěvníka k jednomu jasnému kroku.

## Začněte zde

1. Otevřete **`00-START-HERE.html`** — vizuální přehled, co balíček obsahuje a v jakém pořadí jej projít.
2. Otevřete **`site/index.html`** — hotovou responzivní ukázku šablony s fotografiemi.
3. V souboru **`OBSAH-A-FORMULAR.md`** přepište služby, otázky k poptávce a vlastní kontakty.

## Co přesně uvidíte v šabloně

- **Hero sekci s reálnou fotografií mechanika** a hlavní akcí „Chci termín servisu“;
- **čtyři bloky služeb**, které ukazují zákazníkovi, co čekat od servisu, pneuservisu, diagnostiky a detailingu;
- **jednoduchou cestu poptávky**: popsat potřebu → potvrdit rozsah → domluvit termín;
- kontaktní blok připravený pro telefon, formulář nebo schválený rezervační systém.

## Obsah balíčku

| Soubor | Účel |
|---|---|
| `00-START-HERE.html` | Vizuální rozcestník a rychlý produktový náhled |
| `site/index.html` | Samostatná responsivní ukázka webu s lokálními fotografiemi |
| `assets/` | Lokální referenční fotografie použité v ukázce |
| `OBSAH-A-FORMULAR.md` | Obsahová kostra, otázky pro poptávku a kontrola před spuštěním |
| `FOTOGRAFIE-A-LICENCE.md` | Jak bezpečně nahradit ukázkové fotografie vlastními podklady |
| `LICENCE-INTERNI-POUZITI.md` | Pravidla interního použití |

## Než šablonu zveřejníte

- nahraďte název firmy, telefon, e-mail, město, otevírací dobu a reálné služby;
- vyměňte referenční fotografie za vlastní fotografie nebo podklady s oprávněním k použití;
- připojte formulář až po ověření příjemce dat, ochrany soukromí a potvrzení odeslání;
- otestujte telefon, CTA, formulář a mobilní zobrazení na skutečném zařízení.

> Šablona je výchozí návrh. Odpovědnost za ceny, konkrétní služby, právní texty a skutečné objednávkové procesy zůstává na provozovateli webu.

# Fotografie a použití — Autoservis Start

Balíček obsahuje dvě **referenční fotografie práce v autoservisu**. Slouží výhradně k tomu, aby ukázková šablona po otevření působila jako reálný web a bylo zřejmé, kam patří vlastní vizuální důkazy.

- `assets/autoservis-hero.webp` — mechanik při práci na voze;
- `assets/autoservis-dilna.webp` — pracovní prostředí autoservisní dílny.

Fotografie byly vybrány z volně dostupných stock podkladů Pexels pro interní demonstraci. **Před veřejným nasazením je nahraďte vlastními fotografiemi nebo obrázky s doloženým oprávněním k použití.** Neuvádějte, že zachycený servis, osoba nebo vůz představuje vaši firmu, pokud tomu tak není.

Doporučený náhradní obsah: široká fotografie dílny, detail skutečné práce, vůz na zvedáku, předání vozu nebo reálný tým. Každý snímek opatřete popisným alternativním textem.

# ROSTIVO Digital Komplekt — začněte zde

Komplekt obsahuje pět samostatných interních digitálních produktů. Vyberte vždy **jeden výchozí cíl**, dokončete základní kontrolu a až potom otevírejte další pracovní balíček.

| Pořadí | Balíček | Kdy jej otevřít |
|---:|---|---|
| 01 | Autoservis Start | Potřebujete rychlý webový základ pro autoservis, pneu nebo detailing. |
| 02 | Stavby Pro | Připravujete prezentaci stavební firmy, rekonstrukcí nebo řemesla. |
| 03 | SEO Viditelnost Pro | Potřebujete zkontrolovat dohledatelnost, obsah, indexaci a technický základ existujícího webu. |
| 04 | Core Web Vitals Pro | Řešíte rychlost, odezvu nebo stabilitu a chcete připravit přesné technické zadání. |
| 05 | CRO & UX Audit Pro | Chcete zlepšit konkrétní cestu návštěvníka, formulář, košík nebo mobilní průchod. |

## Doporučené pořadí u existujícího webu

1. Ujasněte si nabídku, cíl stránky a hlavní cestu návštěvníka.
2. Proveďte základní SEO kontrolu.
3. Změřte výkon klíčové URL.
4. Teprve potom prioritizujte CRO / UX úpravy.

Balíčky jsou pracovní podklady. Nezveřejňujte vzorové kontakty, neověřené reference, cizí fotografie nebo technické změny bez kontroly vlastního webu.

# ROSTIVO Digital Komplekt — začněte zde

Komplekt obsahuje pět samostatných interních digitálních produktů. Každý z nich má soubor **`00-START-HERE.html`** s reálnou fotografií, jednovětým hookem, přehledem výsledku a doporučeným prvním krokem. Otevřete jej vždy jako první — až potom pracovní soubory.

| Pořadí | Balíček | Co uvidíte po otevření | Kdy jej použít |
|---:|---|---|---|
| 01 | Autoservis Start | Web s reálnou dílnou, službami a CTA na termín | Potřebujete rychlý webový základ pro autoservis, pneu nebo detailing. |
| 02 | Stavby Pro | Realizaci, příběh cíl → rozsah → výsledek a poptávku | Připravujete prezentaci stavební firmy, rekonstrukcí nebo řemesla. |
| 03 | SEO Viditelnost Pro | Analytický kontext, URL inventář a checklist priorit | Potřebujete zkontrolovat dohledatelnost, obsah, indexaci a technický základ existujícího webu. |
| 04 | Core Web Vitals Pro | Výkonový dashboard, metriky a měřicí tabulku | Řešíte rychlost, odezvu nebo stabilitu a chcete připravit přesné technické zadání. |
| 05 | CRO & UX Audit Pro | Nákupní cestu, mobilní průchod a priority hypotéz | Chcete zlepšit konkrétní cestu návštěvníka, formulář, košík nebo mobilní průchod. |

## Doporučené pořadí u existujícího webu

1. Ujasněte si nabídku, cíl stránky a hlavní cestu návštěvníka.
2. Proveďte základní SEO kontrolu.
3. Změřte výkon klíčové URL.
4. Teprve potom prioritizujte CRO / UX úpravy.

Balíčky jsou pracovní podklady. Nezveřejňujte vzorové kontakty, neověřené reference, cizí fotografie nebo technické změny bez kontroly vlastního webu.

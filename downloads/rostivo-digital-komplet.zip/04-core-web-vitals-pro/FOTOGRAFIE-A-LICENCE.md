# Fotografie a použití — Core Web Vitals Pro

Součástí balíčku je referenční fotografie výkonového dashboardu:

- `assets/vykonovy-dashboard.webp` — vizuální kontext měření rychlosti a chování návštěvníků.

Obrázek ilustruje, jak může vypadat výkonový kontext. **Není to výsledek měření vašeho webu** a nenahrazuje data z PageSpeed Insights, Search Console nebo vlastního monitoringu.

Před veřejným použitím nahraďte fotografii vlastním anonymizovaným náhledem nebo podkladem, k němuž máte právo použití. Nezveřejňujte cizí data, URL ani přístupy.

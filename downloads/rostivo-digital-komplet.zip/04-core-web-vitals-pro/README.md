# Core Web Vitals Pro — vizuální pracovní manuál

![Výkonový dashboard Core Web Vitals Pro](assets/vykonovy-dashboard.webp)

> **Hook:** Nehoňte číslo. Najděte nejdražší zdržení návštěvníka.

Balíček převádí LCP, INP a CLS z neurčitých metrik do pracovního postupu: **změřit → najít pravděpodobnou příčinu → určit prioritu → ověřit změnu**. Nezaměňuje jeden laboratorní test za zkušenost všech návštěvníků a negarantuje skóre, SEO pozici ani konverzní výsledek.

## Začněte zde

1. Otevřete **`00-START-HERE.html`** — vizuální přehled a pořadí práce.
2. Do **`MERENI-A-PRIORITY.csv`** vložte jednu klíčovou URL a měření pro mobil i desktop.
3. Otevřete **`CLS-STABILNI-MEDIUM.html`** a prohlédněte si konkrétní pattern pro stabilní média.

## Co přesně dostanete

- vizuální kontext výkonového dashboardu a cesty od dat k opravě;
- pracovní tabulku LCP, INP a CLS pro terénní i laboratorní poznámky;
- šablonu priority pro vývojáře, aby se neřešilo vše najednou;
- samostatnou HTML ukázku rezervace místa pro médium, které omezuje CLS.

## Tři metriky

| Metrika | Cíl | Co popisuje |
|---|---:|---|
| LCP | ≤ 2,5 s | Zobrazení hlavního obsahu |
| INP | ≤ 200 ms | Odezvu na interakci |
| CLS | ≤ 0,1 | Stabilitu rozvržení |

## Obsah balíčku

| Soubor | Účel |
|---|---|
| `00-START-HERE.html` | Vizuální rozcestník a produktový náhled |
| `MERENI-A-PRIORITY.csv` | Pracovní tabulka priorit |
| `CLS-STABILNI-MEDIUM.html` | Ukázkový pattern pro stabilní média |
| `PRIORITY-TEMPLATE.md` | Zadání pro vývojáře |
| `assets/vykonovy-dashboard.webp` | Vizuální kontext produktu |
| `FOTOGRAFIE-A-LICENCE.md` | Kontext referenční fotografie |
| `LICENCE-INTERNI-POUZITI.md` | Pravidla interního použití |

Oficiální definice a prahy: https://developers.google.com/search/docs/appearance/core-web-vitals

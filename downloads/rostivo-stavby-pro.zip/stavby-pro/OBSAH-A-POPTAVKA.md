# Stavby Pro — obsah, realizace a poptávka

## Pět bloků, které má návštěvník pochopit

1. **Co firma dělá:** konkrétní typy staveb nebo rekonstrukcí a oblast působnosti.
2. **Proč jí věřit:** kvalifikace, počet let praxe, postup, reference se souhlasem, pojištění nebo konkrétní materiály — jen ověřitelné údaje.
3. **Jak vypadá realizace:** problém, rozsah, použité řešení a výsledek. Nejen fotogalerie bez vysvětlení.
4. **Jak spolupráce probíhá:** první kontakt, zaměření / návrh, nabídka, realizace, předání.
5. **Co vyplnit v poptávce:** místo, typ práce, přibližný rozsah, termín, fotografie pouze pokud jsou potřebné.

## Pole kvalifikované poptávky

- jméno, telefon nebo e-mail;
- obec a typ objektu;
- vybraná služba;
- stručný popis rozsahu;
- orientační časový rámec;
- dobrovolná příloha s omezením velikosti a popisem použití;
- souhlas s kontaktováním a odkaz na ochranu soukromí.

## Před spuštěním

- [ ] Každé tvrzení o certifikaci, ceně nebo termínu je ověřené.
- [ ] Reference a fotografie mají souhlas s použitím.
- [ ] Formulář nevyžaduje zbytečné osobní údaje.
- [ ] Přílohy jsou chráněné proti nežádoucímu nahrávání.
- [ ] Telefon, e-mail, mapa a tlačítko poptávky fungují na mobilu.

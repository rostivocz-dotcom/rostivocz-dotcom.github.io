# Stavby Pro — interní balíček

Samostatná výchozí šablona pro stavební firmu, rekonstrukce nebo řemeslo. Balíček je zaměřený na důvěru, realizace, pracovní postup a kvalifikovanou poptávku. Neobsahuje hosting, formulářové API, měření ani fotografie třetích stran.

## Obsah

| Soubor | Účel |
|---|---|
| `site/index.html` | Samostatná responsivní výchozí šablona |
| `OBSAH-A-POPTAVKA.md` | Osnova stránek, realizací a kvalifikované poptávky |
| `../LICENCE-INTERNI-POUZITI.md` | Pravidla interního použití |

## Nasazení

1. Vytvořte kopii složky `site` pro konkrétní firmu.
2. Nahraďte vzorové služby, kontakty, oblast působnosti a text o postupu.
3. Přidejte pouze skutečné realizace a fotografie s oprávněním k použití.
4. Poptávkový formulář připojte až po potvrzení datových toků a příjemce e-mailů.
5. Před spuštěním projděte mobil, odkaz na telefon, formulář, HTTPS, kontakty a ochranu soukromí.

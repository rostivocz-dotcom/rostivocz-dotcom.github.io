# Stavby Pro — vizuální webová šablona

![Náhled Stavby Pro](assets/rekonstrukce-rodinneho-domu.webp)

> **Hook:** Z fotky realizace k důvěře a kvalifikované poptávce.

Balíček ukazuje, jak proměnit skutečnou realizaci ve srozumitelnou webovou cestu. Návštěvník nevidí jen anonymní galerii: pochopí **cíl projektu, rozsah práce, výsledek** a ví, co napsat do poptávky.

## Začněte zde

1. Otevřete **`00-START-HERE.html`** — vizuální rozcestník s přehledem přínosu a souborů.
2. Otevřete **`site/index.html`** — responzivní ukázku šablony s reálnou fotografií rekonstrukce.
3. V souboru **`OBSAH-A-POPTAVKA.md`** připravte vlastní realizace, obsah služeb a otázky pro poptávku.

## Co přesně uvidíte v šabloně

- **silnou hero sekci s reálnou fotkou realizace** a jasnou výzvou k poptávce;
- bloky pro rekonstrukce, nové stavby a řemeslné práce;
- strukturu příběhu realizace: **cíl → rozsah → výsledek**;
- poptávkový blok, který sbírá místo, rozsah a termín místo vágního „ozvěte se“.

## Obsah balíčku

| Soubor | Účel |
|---|---|
| `00-START-HERE.html` | Vizuální rozcestník a rychlý produktový náhled |
| `site/index.html` | Samostatná responsivní ukázka webu s lokální fotografií realizace |
| `assets/` | Lokální referenční fotografie použitá v ukázce |
| `OBSAH-A-POPTAVKA.md` | Osnova stránek, realizací a kvalifikované poptávky |
| `FOTOGRAFIE-A-LICENCE.md` | Jak bezpečně nahradit ukázkovou fotografii vlastními podklady |
| `LICENCE-INTERNI-POUZITI.md` | Pravidla interního použití |

## Než šablonu zveřejníte

- nahraďte ukázkovou realizaci vlastní zakázkou, ke které máte souhlas;
- doplňte pravdivý rozsah prací, lokality a dostupnost;
- propojte formulář teprve po potvrzení příjemce dat a zásad ochrany soukromí;
- ověřte mobil, odkazy, telefon, formulář a všechny důkazy před spuštěním.

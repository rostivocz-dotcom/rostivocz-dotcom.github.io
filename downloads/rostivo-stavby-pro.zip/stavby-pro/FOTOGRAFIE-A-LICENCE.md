# Fotografie a použití — Stavby Pro

Součástí balíčku je **referenční fotografie rozpracované rekonstrukce rodinného domu**. Ukazuje, jak má reálná realizace fungovat jako první vizuální důkaz na webu stavební firmy.

- `assets/rekonstrukce-rodinneho-domu.webp` — referenční snímek rekonstrukce.

Fotografie slouží jako interní demonstrace rozvržení. **Před veřejným nasazením ji vždy nahraďte vlastní realizací nebo podkladem s písemně ověřeným oprávněním k použití.** Neuvádějte ji jako vlastní zakázku, pokud ji vaše firma nerealizovala.

Doporučený náhradní obsah: jeden široký záběr projektu, jeden detail materiálu či řemesla a u každé realizace stručně cíl, rozsah a výsledek. U snímků uveďte smysluplný alternativní text.

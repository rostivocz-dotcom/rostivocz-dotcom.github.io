# Core Web Vitals Pro — pracovní manuál

Balíček slouží pro měření, hledání pravděpodobné příčiny a přípravu ověřitelné opravy. Nezaměňuje jeden laboratorní test za zkušenost všech návštěvníků a negarantuje skóre, SEO pozici ani konverzní výsledek.

## Tři metriky

| Metrika | Cíl | Co popisuje |
|---|---:|---|
| LCP | ≤ 2,5 s | Zobrazení hlavního obsahu |
| INP | ≤ 200 ms | Odezvu na interakci |
| CLS | ≤ 0,1 | Stabilitu rozvržení |

## Postup

1. Vyberte jednu klíčovou URL a hlavní úkol návštěvníka.
2. Zapište terénní data z PageSpeed Insights/Search Console pro mobil i desktop, pokud jsou k dispozici.
3. V laboratoři použijte Lighthouse nebo DevTools k reprodukci a hledání příčiny, ne jako konečný verdikt.
4. Seřaďte příčiny: hlavní vizuál a média, blokující zdroje, JavaScript, externí skripty, rozvržení, server/cache.
5. Proveďte jednu konkrétní změnu, otestujte ji v laboratoři a poznamenejte případné vedlejší dopady.
6. V terénních datech sledujte změnu v čase; PSI pracuje s agregovanými daty za předchozí období.

## Obsah balíčku

- `MERENI-A-PRIORITY.csv` — pracovní tabulka;
- `CLS-STABILNI-MEDIUM.html` — ukázkový pattern pro rezervaci místa média;
- `PRIORITY-TEMPLATE.md` — zadání pro vývojáře;
- `LICENCE-INTERNI-POUZITI.md` — pravidla použití.

Oficiální definice a prahy: https://developers.google.com/search/docs/appearance/core-web-vitals

# Core Web Vitals Pro — zadání opravy

```text
URL a šablona:
Zařízení a hlavní úkol návštěvníka:
Terénní data (datum + zdroj):
Laboratorní reprodukce (nástroj + podmínky):
Pozorovaný symptom:
Pravděpodobná příčina:
Navrhovaná změna:
Co se nemá změnou rozbít:
Závislost (CMS / vývoj / hosting / třetí strana):
Ověření v laboratoři:
Ověření v provozu:
Vlastník a termín:
```

## Příklad správného rozsahu

„Na mobilní produktové šabloně ověřit, zda největší vizuál nad přehybem blokuje LCP. Pokud ano, připravit správný zdroj a rozměry, zkontrolovat kritické načtení a porovnat laboratorní průběh před/po. V další periodě sledovat dostupná terénní data.“

To je přesnější než požadavek „zrychlit web“ a zároveň neslibuje konkrétní výsledek bez měření.

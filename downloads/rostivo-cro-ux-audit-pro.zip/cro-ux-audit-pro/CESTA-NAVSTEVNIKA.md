# CRO & UX Audit Pro — mapa cesty návštěvníka

| Krok | Stránka / událost | Co návštěvník hledá | Co mu může chybět | Důkaz nebo kontrola | Další akce |
|---|---|---|---|---|---|
| Vstup |  |  |  |  |  |
| Seznámení s nabídkou |  |  |  |  |  |
| Porovnání / důvěra |  |  |  |  |  |
| CTA / formulář / košík |  |  |  |  |  |
| Potvrzení |  |  |  |  |  |

## Otázky pro průchod

- Je během prvních sekund jasné, co stránka nabízí a pro koho je?
- Vidí návštěvník důkaz, cenu/náklady nebo další krok ve chvíli, kdy to potřebuje?
- Je CTA konkrétní a rozumí tomu, co se stane po kliknutí?
- Má formulář pouze údaje potřebné pro první krok?
- Funguje stránka na mobilu bez zbytečného scrollování, překrytí a chyb?

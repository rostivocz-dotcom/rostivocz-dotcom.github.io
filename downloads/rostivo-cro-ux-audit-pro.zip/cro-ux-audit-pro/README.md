# CRO & UX Audit Pro — pracovní manuál

CRO a UX audit začíná konkrétním cílem návštěvníka, ne tím, že se hned změní design. Úkolem balíčku je propojit signál v datech, skutečný průchod stránkou a ověřitelnou hypotézu. Nezaručuje konkrétní konverzní poměr, tržby ani výsledek A/B testu.

## Pracovní postup

1. Vyberte jednu stránku nebo krok a jediný hlavní úkol návštěvníka.
2. Zapište cestu před a po daném kroku: odkud návštěvník přichází, co musí pochopit a co se má stát dál.
3. Projděte nálevku v GA4, pokud jsou data dostupná. Propad je signál k prověření, ne hotová příčina.
4. Na mobilu ověřte nabídku, CTA, důkazy, cenu/náklady, formulář nebo košík a chybové stavy.
5. Zapište hypotézu s důkazem, prioritou, odpovědností a způsobem vyhodnocení.
6. Proveďte domluvenou změnu a ověřte relevantní krok ve srovnatelném období.

## Obsah balíčku

- `CESTA-NAVSTEVNIKA.md` — pracovní mapa cesty;
- `HYPOTEZY-A-PRIORITY.csv` — prioritizační tabulka;
- `MOBIL-A-FORMULAR-CHECKLIST.md` — kontrolní list;
- `LICENCE-INTERNI-POUZITI.md` — pravidla použití.

Základ pro práci s nálevkou: https://support.google.com/analytics/answer/9327974?hl=en

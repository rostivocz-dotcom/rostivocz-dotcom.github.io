# CRO & UX Audit Pro — vizuální pracovní manuál

![Nákupní krok CRO a UX Audit Pro](assets/cesta-k-nakupu.webp)

> **Hook:** Zjistěte, kde návštěvník přestává věřit nebo pokračovat.

Tento balíček nezačíná redesignem. Začíná skutečnou cestou návštěvníka: co má na stránce pochopit, co mu v tom brání a jak jednu změnu ověřit. Nezaručuje konkrétní konverzní poměr, tržby ani výsledek A/B testu.

## Začněte zde

1. Otevřete **`00-START-HERE.html`** — vizuální přehled přínosu a souborů.
2. V **`CESTA-NAVSTEVNIKA.md`** popište jeden konkrétní krok zákazníka.
3. Zapište první problém do **`HYPOTEZY-A-PRIORITY.csv`** a projděte mobilní variantu s checklistem.

## Co přesně dostanete

- reálný e-commerce kontext nákupního kroku a návštěvnické cesty;
- pracovní mapu cesty návštěvníka před a po rozhodovacím kroku;
- mobilní checklist pro nabídku, CTA, důkazy, cenu, formulář nebo košík;
- tabulku hypotéz, priorit, důkazů, odpovědnosti a způsobu vyhodnocení.

## Obsah balíčku

| Soubor | Účel |
|---|---|
| `00-START-HERE.html` | Vizuální rozcestník a produktový náhled |
| `CESTA-NAVSTEVNIKA.md` | Pracovní mapa cesty návštěvníka |
| `HYPOTEZY-A-PRIORITY.csv` | Tabulka hypotéz, priorit a ověření |
| `MOBIL-A-FORMULAR-CHECKLIST.md` | Kontrolní list pro mobil a formulář |
| `assets/cesta-k-nakupu.webp` | Vizuální kontext produktu |
| `FOTOGRAFIE-A-LICENCE.md` | Kontext referenční fotografie |
| `LICENCE-INTERNI-POUZITI.md` | Pravidla interního použití |

Základ pro práci s nálevkou: https://support.google.com/analytics/answer/9327974?hl=en

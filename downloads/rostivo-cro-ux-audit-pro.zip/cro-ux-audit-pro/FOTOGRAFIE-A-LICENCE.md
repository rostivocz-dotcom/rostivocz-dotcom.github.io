# Fotografie a použití — CRO a UX Audit Pro

Součástí balíčku je referenční fotografie nákupního kroku na e-shopu:

- `assets/cesta-k-nakupu.webp` — vizuální kontext pro práci s košíkem, formulářem a rozhodnutím návštěvníka.

Obrázek je ilustrace produktu. **Není to ukázka vašeho e-shopu ani důkaz konkrétní míry konverze.** Smyslem je rychle vysvětlit, že balíček se týká skutečné návštěvnické cesty a konkrétního kroku k nákupu.

Před veřejným použitím nahraďte fotografii vlastním anonymizovaným náhledem nebo podkladem, k němuž máte právo použití. Nezveřejňujte cizí objednávky, osobní údaje nebo údaje z platebních karet.

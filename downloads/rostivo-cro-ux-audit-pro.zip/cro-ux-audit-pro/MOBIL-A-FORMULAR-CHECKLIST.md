# CRO & UX Audit Pro — mobil a formulář

## Nabídka a CTA

- [ ] Hlavní nabídka je čitelná bez horizontálního posouvání.
- [ ] V prvním pohledu je možné pochopit produkt/službu i další krok.
- [ ] CTA říká, co se stane po kliknutí.
- [ ] Cena, doprava, termín nebo jiná důležitá podmínka nejsou ukryté až na konci cesty.

## Formulář nebo checkout

- [ ] Pole odpovídají účelu; nevyžadují nadbytečná data.
- [ ] E-mail, telefon a čísla vyvolají vhodnou klávesnici.
- [ ] Browser autofill funguje na běžných polích.
- [ ] Chybová zpráva je u srozumitelného pole a nevynuluje formulář.
- [ ] Uživatel může košík nebo objednávku snadno upravit.
- [ ] Po odeslání je jasné potvrzení a další krok.

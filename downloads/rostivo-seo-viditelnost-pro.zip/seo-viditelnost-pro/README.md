# SEO Viditelnost Pro — vizuální pracovní manuál

![Pracovní kontext SEO Viditelnost Pro](assets/seo-pracovni-nahled.webp)

> **Hook:** Z nejasných SEO úkolů jeden konkrétní seznam priorit.

Balíček ukazuje, jak vypadá skutečná pracovní cesta mezi obsahem, URL, indexací a daty. Nezajišťuje konkrétní pozici ve vyhledávání ani návštěvnost — pomáhá připravit **ověřitelný seznam oprav**, který dokážete projít sami nebo předat vývojáři.

## Začněte zde

1. Otevřete **`00-START-HERE.html`** — vizuální přehled balíčku a doporučené pořadí práce.
2. Otevřete **`URL-INVENTAR.csv`** a vyberte první důležité URL.
3. Postupujte podle **`SEO-CHECKLIST.md`**, pak upravte texty pomocí **`TITLE-META-SABLONY.md`**.

## Co přesně dostanete

- reálný vizuální kontext práce s analytikou, URL a prioritami;
- tabulku pro inventář URL, účel stránky, cílový dotaz a stav;
- checklist indexace, obsahu, title, meta description, odkazů a technického základu;
- textové šablony pro title a description, které se přepisují podle skutečného obsahu.

## Obsah balíčku

| Soubor | Účel |
|---|---|
| `00-START-HERE.html` | Vizuální rozcestník a produktový náhled |
| `URL-INVENTAR.csv` | Pracovní tabulka priorit a stavu URL |
| `SEO-CHECKLIST.md` | Kontrolní list podle URL |
| `TITLE-META-SABLONY.md` | Textové vzory pro title a meta description |
| `assets/seo-pracovni-nahled.webp` | Vizuální kontext produktu |
| `FOTOGRAFIE-A-LICENCE.md` | Kontext referenční fotografie |
| `LICENCE-INTERNI-POUZITI.md` | Pravidla interního použití |

## Kdy přizvat odborníka

Pokud je problém napříč stovkami URL, web má nekonzistentní přesměrování, mění se šablony/CMS, nemáte přístup k technickému řešení nebo nevíte, která stránka je kanonická, je lepší problém nejdříve odborně diagnostikovat.

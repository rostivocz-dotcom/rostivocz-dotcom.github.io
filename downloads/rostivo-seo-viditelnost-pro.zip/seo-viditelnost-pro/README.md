# SEO Viditelnost Pro — pracovní manuál

Tento balíček je praktický postup pro základní kontrolu vlastního webu. Nezajišťuje konkrétní pozici ve vyhledávání ani návštěvnost; pomáhá vytvořit ověřitelný seznam priorit a správné zadání pro případného vývojáře.

## Postup od A do Z

1. **Inventář URL:** vyberte nejdůležitější služby, kategorie, produkty a kontaktní cestu. Pro každou URL zapište jeden účel a cílový dotaz návštěvníka.
2. **Indexace:** ověřte, že má být stránka veřejná, vrací správný stav, není omylem blokovaná a má smysluplný canonical.
3. **Viditelný obsah:** zkontrolujte, že H1 odpovídá účelu stránky, informace jsou konkrétní a návštěvník rozumí dalšímu kroku.
4. **Title a description:** napište jedinečný titul a popis, které shrnují skutečný obsah. Neplňte je seznamem klíčových slov.
5. **Vnitřní odkazy:** propojte související služby, realizace a kontakt pomocí přirozených popisků.
6. **Technický základ:** projděte sitemap, robots, obrázky, canonical, odkazy a viditelná chybová hlášení.
7. **Kontrola po publikaci:** otevřete skutečnou veřejnou URL, prohlédněte zdrojový HTML výstup a poznamenávejte datum změny.

## Obsah balíčku

- `SEO-CHECKLIST.md` — kontrolní list podle URL;
- `URL-INVENTAR.csv` — tabulka priorit a stavu;
- `TITLE-META-SABLONY.md` — textové vzory;
- `LICENCE-INTERNI-POUZITI.md` — pravidla použití.

## Kdy přizvat odborníka

Pokud je problém napříč stovkami URL, web má nekonzistentní přesměrování, mění se šablony/CMS, nemáte přístup k technickému řešení nebo nevíte, která stránka je kanonická, je lepší problém nejdříve odborně diagnostikovat.

# SEO Viditelnost Pro — šablony title a meta description

Tyto vzory vždy upravte podle skutečného obsahu URL. Nejsou určené k hromadnému doplňování bez kontroly.

| Typ stránky | Title — výchozí vzor | Meta description — výchozí vzor |
|---|---|---|
| Služba | `[Služba] v [město/oblast] | [značka]` | `Zjistěte, jak probíhá [služba], pro koho je vhodná a jak nás kontaktovat pro další krok.` |
| Kategorie e-shopu | `[Kategorie] | [značka]` | `Prohlédněte [kategorii], důležité vlastnosti a možnosti výběru. Dostupnost a dopravu ověřte u konkrétní položky.` |
| Realizace | `[Typ realizace] — [stručný výsledek] | [značka]` | `Podívejte se na průběh, rozsah a použité řešení konkrétní realizace [typ].` |
| Kontakt | `Kontakt | [značka]` | `Telefon, e-mail, adresa a další možnosti, jak kontaktovat [značku].` |

## Kontrola před publikací

- Je title čitelný i bez znalosti značky?
- Popisuje meta description reálnou stránku, ne přání?
- Neobsahují dva různé URL stejný title bez důvodu?
- Může vyhledávač text upravit? Ano — to je normální; cílem je přesný a užitečný zdrojový obsah.

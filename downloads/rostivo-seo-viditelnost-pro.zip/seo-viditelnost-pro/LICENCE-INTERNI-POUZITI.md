# ROSTIVO Studio — licence pro interní použití

Tento digitální balíček je určený pro interní použití držitele záznamu ROSTIVO Studio a jeho vlastní projekty. Obsah lze upravovat pro vlastní weby, nabídky a pracovní postupy.

Není dovoleno balíček, jeho části ani podstatně podobnou variantu dále prodávat, veřejně redistribuovat nebo vydávat za produkt třetí strany bez samostatného souhlasu vlastníka práv. Fotografie a značky třetích stran nejsou součástí licence, pokud není u konkrétního souboru uvedeno jinak.

Balíčky obsahují pracovní podklady, nikoliv garanci obchodního, SEO nebo konverzního výsledku. Před veřejným nasazením vždy zkontrolujte kontakty, texty, právní informace, přístupnost, měření a technické chování vlastního řešení.

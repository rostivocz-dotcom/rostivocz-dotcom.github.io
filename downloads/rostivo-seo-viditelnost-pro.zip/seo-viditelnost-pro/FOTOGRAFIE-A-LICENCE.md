# Fotografie a použití — SEO Viditelnost Pro

Součástí balíčku je referenční fotografie práce s analytickým rozhraním:

- `assets/seo-pracovni-nahled.webp` — vizuální kontext práce s daty, URL a prioritami.

Obrázek není audit vašeho webu, neobsahuje vaše data a neslouží jako důkaz konkrétního výsledku. Je zde proto, aby byl po otevření balíčku jasný praktický kontext produktu.

Před veřejným použitím nahraďte fotografii vlastním anonymizovaným náhledem nebo podkladem, k němuž máte právo použití. Nezveřejňujte cizí analytická data, osobní údaje ani přístupové informace.

# SEO Viditelnost Pro — checklist pro jednu URL

## Účel a obsah

- [ ] URL má jeden zřetelný účel a odpovídá na konkrétní potřebu návštěvníka.
- [ ] H1 srozumitelně popisuje obsah a není jen slogan.
- [ ] Nadpisy dávají delšímu obsahu smysluplnou strukturu.
- [ ] Nabídka, důkazy a další krok jsou na stránce dohledatelné bez hádání.

## Snippet a indexace

- [ ] Title je jedinečný, odpovídá obsahu a neobsahuje opakované klíčové fráze.
- [ ] Meta description shrnuje skutečný přínos stránky a neslibuje nemožné.
- [ ] Canonical míří na zamýšlenou preferovanou URL.
- [ ] Stránka, kterou chcete hledat, není omylem `noindex` nebo blokovaná robots pravidlem.
- [ ] URL je zahrnutá v sitemap, pokud jde o důležitou indexovatelnou stránku.

## Propojení a média

- [ ] Související stránky jsou propojené popisnými interními odkazy.
- [ ] Obrázky mají vhodný alternativní text, když nesou význam.
- [ ] Odkazy, formuláře a CTA fungují na mobilu.
- [ ] Po publikaci je zkontrolovaná skutečná veřejná stránka, ne jen editor.
